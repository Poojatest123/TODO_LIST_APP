import TodoList from './Component/TodoList';

function App() {
  return (
    <>
    <TodoList/>
    </>
  );
}

export default App;
